function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6l4QNL6A545":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

